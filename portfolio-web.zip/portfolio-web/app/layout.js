export const metadata = {
  title: "Asesor Financiero",
  description: "Portfolio advisor powered by AI",
};

export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <body style={{ margin: 0, padding: 0, background: "#06090f" }}>
        {children}
      </body>
    </html>
  );
}
