"use client";
import { useState, useRef, useEffect } from "react";
import * as XLSX from "xlsx";

// ─── DATOS DE CARTERA ────────────────────────────────────────────────────────
const BONOS = [
  { ticker:"AE38", qty:879,      label:"879 nom.",      precio:1164.40, actual:1023508, inicial:991187,  rend:32321,   varP:0.50,  tipo:"Soberano USD Ley Ext. 2038", moneda:"ARS" },
  { ticker:"AL30", qty:1214,     label:"1214 nom.",     precio:917.40,  actual:1113724, inicial:1052855, rend:60868,   varP:0.23,  tipo:"Soberano USD Ley Local 2030", moneda:"ARS" },
  { ticker:"GD30", qty:1982,     label:"1982 nom.",     precio:935.00,  actual:1853170, inicial:1756756, rend:96414,   varP:0.43,  tipo:"Global USD Ley Ext. 2030",   moneda:"ARS" },
  { ticker:"GD41", qty:2184,     label:"2184 nom.",     precio:1074.00, actual:2345616, inicial:2188805, rend:156811,  varP:1.32,  tipo:"Global USD Ley Ext. 2041",   moneda:"ARS" },
];
const CORPORATIVOS = [
  { ticker:"IRCPO", qty:3098,   label:"3098 nom.",     precio:1560.50, actual:4834429, inicial:0,       rend:4834429, varP:0.35,  tipo:"IRSA Prop. Comerciales ON",  moneda:"ARS" },
  { ticker:"OLC6O", qty:3168,   label:"3168 nom.",     precio:1537.00, actual:4869216, inicial:4667446, rend:201770,  varP:0.69,  tipo:"Oleoducto del Valle ON",      moneda:"ARS" },
];
const FONDOS = [
  { ticker:"BCMMA", qty:11937,  label:"11.937 cuotas", precio:11.75,   actual:140261,  inicial:130001,  rend:10260,   varP:0.05,  tipo:"Money Market Balanz",         moneda:"ARS" },
];
const ACCIONES = [
  { ticker:"GLOB",  qty:39,     label:"39 acciones",   precio:40.69,   actual:1586.91, inicial:1657.50, rend:-70.59,  varP:-4.26, tipo:"Globant S.A. · NYSE",         moneda:"USD", objetivo:60, compra:42.50 },
];

const ARS_ACTUAL  = 1023508+1113724+1853170+2345616+4834429+4869216+140261;
const ARS_INICIAL = 991187+1052855+1756756+2188805+0+4667446+130001;
const ARS_REND    = ARS_ACTUAL - ARS_INICIAL;

// ─── HELPERS ─────────────────────────────────────────────────────────────────
const fmtARS = (n) => {
  if (n === null || n === undefined || isNaN(n)) return "—";
  const a = Math.abs(n), s = n < 0 ? "-" : "";
  if (a >= 1000000) return `${s}$${(a/1000000).toFixed(2)}M`;
  if (a >= 1000)    return `${s}$${(a/1000).toFixed(1)}K`;
  return `${s}$${a.toFixed(0)}`;
};
const fmtUSD = (n) => {
  if (n === null || n === undefined || isNaN(n)) return "—";
  const s = n < 0 ? "-" : "";
  return `${s}$${Math.abs(n).toFixed(0)} USD`;
};
const signStr = (n) => n >= 0 ? "+" : "";
const pctStr  = (n)  => isNaN(n) ? "—" : `${signStr(n)}${n.toFixed(2)}%`;
const fmtMsg  = (t)  => t
  .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
  .replace(/\*(.+?)\*/g, "<em>$1</em>")
  .replace(/\n/g, "<br/>");

// ─── SYSTEM PROMPT ────────────────────────────────────────────────────────────
const SYSTEM_PROMPT = `Sos un asesor financiero experto en mercados argentinos e internacionales.

CARTERA COMPLETA DEL USUARIO:

BONOS SOBERANOS (ARS):
- AE38 (Ley Ext. 2038): 879 nom | Actual $1,023,508 | Rend +$32,321 (+0.50%)
- AL30 (Ley Local 2030): 1214 nom | Actual $1,113,724 | Rend +$60,868 (+0.23%)
- GD30 (Global 2030): 1982 nom | Actual $1,853,170 | Rend +$96,414 (+0.43%)
- GD41 (Global 2041): 2184 nom | Actual $2,345,616 | Rend +$156,811 (+1.32%)

CORPORATIVOS ON (ARS):
- IRCPO (IRSA Prop. Comerciales): 3098 nom | Actual $4,834,429
- OLC6O (Oleoducto del Valle): 3168 nom | Actual $4,869,216 | Rend +$201,770

FONDOS (ARS):
- BCMMA (Money Market Balanz): 11,937 cuotas | Actual $140,261 | Rend +$10,260

ACCIONES INTERNACIONALES (USD):
- GLOB (Globant S.A., NYSE): 39 acciones | Compra $42.50 | Precio actual ~$40.69 | Valor ~$1,587 USD | P&L -$70 USD (-4.26%) | Objetivo $60 USD | Earnings 14 mayo 2026

TOTALES: ~$16,180,000 ARS + $1,587 USD

Responde siempre en espanol. Usa web_search para datos frescos. Da recomendaciones directas.`;

// ─── ASSET ROW ────────────────────────────────────────────────────────────────
function AssetRow({ item, onAsk }) {
  const isUSD  = item.moneda === "USD";
  const isLoss = item.rend < 0;
  const rendColor    = isLoss ? "#fc8181" : "#68d391";
  const rendDisplay  = isUSD ? `${signStr(item.rend)}${fmtUSD(item.rend)}` : `${signStr(item.rend)}${fmtARS(item.rend)}`;
  const actualDisplay = isUSD ? fmtUSD(item.actual) : fmtARS(item.actual);

  return (
    <div
      onClick={() => onAsk(`Analiza ${item.ticker}: perspectivas actuales y que hago con mi posicion de ${item.qty} ${isUSD ? "acciones" : "nominales"}`)}
      style={{
        background: isUSD ? "rgba(104,211,145,0.05)" : "rgba(255,255,255,0.03)",
        border: isUSD ? "1px solid rgba(104,211,145,0.2)" : "1px solid rgba(255,255,255,0.06)",
        borderRadius:"9px", padding:"9px 13px", marginBottom:"5px",
        display:"grid", gridTemplateColumns:"72px 1fr 90px 90px 62px",
        alignItems:"center", gap:"6px", cursor:"pointer", transition:"background 0.15s",
      }}
      onMouseOver={e => e.currentTarget.style.background = isUSD ? "rgba(104,211,145,0.1)" : "rgba(255,255,255,0.06)"}
      onMouseOut={e  => e.currentTarget.style.background = isUSD ? "rgba(104,211,145,0.05)" : "rgba(255,255,255,0.03)"}
    >
      <div>
        <div style={{ display:"flex", alignItems:"center", gap:"4px" }}>
          <span style={{ color:"#fff", fontWeight:"700", fontFamily:"monospace", fontSize:"12px" }}>{item.ticker}</span>
          {isUSD && <span style={{ background:"rgba(104,211,145,0.2)", color:"#68d391", fontSize:"7px", fontFamily:"monospace", padding:"1px 4px", borderRadius:"3px" }}>USD</span>}
        </div>
        <div style={{ color:"rgba(255,255,255,0.3)", fontSize:"9px", fontFamily:"monospace", marginTop:"1px" }}>{item.label}</div>
      </div>
      <div style={{ lineHeight:"1.4" }}>
        <div style={{ color:"rgba(255,255,255,0.28)", fontSize:"9px", fontFamily:"monospace" }}>{item.tipo}</div>
        {item.objetivo && (
          <div style={{ color:"rgba(104,211,145,0.6)", fontSize:"8px", fontFamily:"monospace", marginTop:"1px" }}>
            meta ${item.objetivo} · compra ${item.compra}
          </div>
        )}
      </div>
      <div style={{ textAlign:"right" }}>
        <div style={{ color:"#e2e8f0", fontFamily:"monospace", fontSize:"11px" }}>{actualDisplay}</div>
        <div style={{ color:"rgba(255,255,255,0.2)", fontSize:"8px", fontFamily:"monospace" }}>actual</div>
      </div>
      <div style={{ textAlign:"right" }}>
        <div style={{ color:rendColor, fontFamily:"monospace", fontSize:"11px" }}>{rendDisplay}</div>
        <div style={{ color:"rgba(255,255,255,0.2)", fontSize:"8px", fontFamily:"monospace" }}>rend.</div>
      </div>
      <div style={{ background: isLoss ? "rgba(252,129,129,0.1)" : "rgba(104,211,145,0.1)", color: isLoss ? "#fc8181" : "#68d391", borderRadius:"5px", padding:"2px 6px", fontFamily:"monospace", fontSize:"10px", textAlign:"center" }}>
        {pctStr(item.varP)}
      </div>
    </div>
  );
}

// ─── HOLDINGS TAB ─────────────────────────────────────────────────────────────
function HoldingsTab({ onAsk }) {
  const sections = [
    { label:"Bonos Soberanos", color:"#63b3ed", items: BONOS },
    { label:"Corporativos ON", color:"#b794f4", items: CORPORATIVOS },
    { label:"Fondos",          color:"#f6ad55", items: FONDOS },
    { label:"Acciones NYSE",   color:"#68d391", items: ACCIONES },
  ];
  return (
    <div style={{ padding:"18px", maxHeight:"500px", overflowY:"auto", scrollbarWidth:"thin", scrollbarColor:"rgba(255,255,255,0.06) transparent" }}>
      {sections.map(({ label, color, items }) => (
        <div key={label} style={{ marginBottom:"18px" }}>
          <div style={{ display:"flex", alignItems:"center", gap:"7px", marginBottom:"8px" }}>
            <div style={{ width:"3px", height:"13px", borderRadius:"2px", background:color }} />
            <span style={{ color, fontSize:"10px", fontFamily:"monospace", letterSpacing:"1.5px", textTransform:"uppercase" }}>{label}</span>
          </div>
          {items.map(item => <AssetRow key={item.ticker} item={item} onAsk={onAsk} />)}
        </div>
      ))}
      <p style={{ color:"rgba(255,255,255,0.18)", fontSize:"9px", fontFamily:"monospace", textAlign:"center", margin:"4px 0 0" }}>
        Toca cualquier activo para analizarlo en el chat
      </p>
    </div>
  );
}

// ─── EXCEL TAB ────────────────────────────────────────────────────────────────
function ExcelTab() {
  const [rows, setRows]           = useState([]);
  const [headers, setHeaders]     = useState([]);
  const [fileName, setFileName]   = useState("");
  const [analyzing, setAnalyzing] = useState(false);
  const [report, setReport]       = useState("");
  const [error, setError]         = useState("");
  const [dragOver, setDragOver]   = useState(false);
  const fileRef = useRef();

  const parseFile = (file) => {
    setError(""); setReport(""); setRows([]); setHeaders([]);
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const wb   = XLSX.read(e.target.result, { type:"binary", cellDates:true });
        const ws   = wb.Sheets[wb.SheetNames[0]];
        const data = XLSX.utils.sheet_to_json(ws, { header:1, defval:"" });
        if (data.length < 2) { setError("El archivo parece vacio."); return; }
        setHeaders(data[0].map(String));
        setRows(data.slice(1).filter(r => r.some(c => c !== "")));
      } catch { setError("No se pudo leer el archivo. Verificá que sea .xlsx o .csv."); }
    };
    reader.readAsBinaryString(file);
  };

  const handleFile = (e) => { if (e.target.files[0]) parseFile(e.target.files[0]); };
  const handleDrop = (e) => { e.preventDefault(); setDragOver(false); if (e.dataTransfer.files[0]) parseFile(e.dataTransfer.files[0]); };

  const analyze = async () => {
    if (!rows.length) return;
    setAnalyzing(true); setReport("");
    const table = [headers.join(" | "), ...rows.slice(0,80).map(r => r.join(" | "))].join("\n");
    const prompt = `Analiza el historial de movimientos y genera un informe completo.\n\nARCHIVO: "${fileName}"\nDATOS:\n${table}${rows.length>80?`\n... (${rows.length-80} filas mas)`:""}

Cartera actual de referencia: ~$16,180,000 ARS + $1,587 USD (GLOB NYSE).

Genera el informe con:
1. RESUMEN DE MOVIMIENTOS
2. RENTABILIDAD (ganancia/perdida por activo, total en $ y %)
3. MEJOR ESTRATEGIA? (compara contra plazo fijo, dolar CCL/MEP e inflacion IPC - busca datos reales)
4. VEREDICTO Y RECOMENDACIONES`;

    try {
      const res  = await fetch("/api/chat", { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ model:"claude-sonnet-4-20250514", max_tokens:8000, system:SYSTEM_PROMPT, tools:[{ type:"web_search_20250305", name:"web_search" }], messages:[{ role:"user", content:prompt }] }) });
      const data = await res.json();
      setReport(data.content?.filter(b => b.type==="text").map(b => b.text).join("") || "Sin respuesta.");
    } catch { setReport("Error al analizar. Intenta de nuevo."); }
    finally { setAnalyzing(false); }
  };

  if (report) return (
    <div style={{ padding:"18px", display:"flex", flexDirection:"column", gap:"12px", maxHeight:"500px", overflowY:"auto", scrollbarWidth:"thin" }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
        <span style={{ color:"#63b3ed", fontSize:"10px", fontFamily:"monospace", letterSpacing:"1.5px" }}>INFORME — {new Date().toLocaleDateString("es-AR")}</span>
        <button onClick={() => { setRows([]); setHeaders([]); setFileName(""); setReport(""); }} style={{ background:"rgba(255,255,255,0.05)", border:"1px solid rgba(255,255,255,0.1)", borderRadius:"7px", padding:"5px 12px", color:"rgba(255,255,255,0.4)", fontSize:"10px", cursor:"pointer", fontFamily:"system-ui,sans-serif" }}>Nuevo archivo</button>
      </div>
      <div style={{ padding:"16px 18px", background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:"12px", color:"#dde8f0", fontSize:"13px", lineHeight:"1.85", fontFamily:"Georgia,serif" }}>
        <div dangerouslySetInnerHTML={{ __html: fmtMsg(report) }} />
      </div>
    </div>
  );

  return (
    <div style={{ padding:"18px", display:"flex", flexDirection:"column", gap:"14px" }}>
      {!rows.length ? (
        <div onDragOver={e => { e.preventDefault(); setDragOver(true); }} onDragLeave={() => setDragOver(false)} onDrop={handleDrop} onClick={() => fileRef.current.click()}
          style={{ border:`2px dashed ${dragOver ? "rgba(99,179,237,0.6)" : "rgba(255,255,255,0.1)"}`, borderRadius:"14px", padding:"40px 20px", display:"flex", flexDirection:"column", alignItems:"center", gap:"10px", cursor:"pointer", background: dragOver ? "rgba(99,179,237,0.05)" : "transparent", transition:"all 0.2s" }}>
          <div style={{ fontSize:"32px" }}>📂</div>
          <div style={{ color:"#fff", fontSize:"14px", fontFamily:"system-ui,sans-serif", fontWeight:"600" }}>Subi tu Excel de movimientos</div>
          <div style={{ color:"rgba(255,255,255,0.35)", fontSize:"11px", fontFamily:"monospace", textAlign:"center", lineHeight:"1.6" }}>Arrasta el archivo o hace click<br/>Formatos: .xlsx · .xls · .csv</div>
          <div style={{ background:"rgba(99,179,237,0.12)", border:"1px solid rgba(99,179,237,0.2)", borderRadius:"8px", padding:"7px 18px", color:"#63b3ed", fontSize:"12px", fontFamily:"system-ui,sans-serif" }}>Seleccionar archivo</div>
          <input ref={fileRef} type="file" accept=".xlsx,.xls,.csv" onChange={handleFile} style={{ display:"none" }} />
        </div>
      ) : (
        <>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
            <div>
              <div style={{ color:"#fff", fontSize:"13px", fontFamily:"system-ui,sans-serif", fontWeight:"600" }}>📄 {fileName}</div>
              <div style={{ color:"rgba(255,255,255,0.3)", fontSize:"10px", fontFamily:"monospace", marginTop:"2px" }}>{rows.length} movimientos · {headers.length} columnas</div>
            </div>
            <div style={{ display:"flex", gap:"8px" }}>
              <button onClick={() => { setRows([]); setHeaders([]); setFileName(""); }} style={{ background:"rgba(255,255,255,0.05)", border:"1px solid rgba(255,255,255,0.1)", borderRadius:"7px", padding:"6px 12px", color:"rgba(255,255,255,0.4)", fontSize:"11px", cursor:"pointer", fontFamily:"system-ui,sans-serif" }}>Cambiar</button>
              <button onClick={analyze} disabled={analyzing} style={{ background: analyzing ? "rgba(99,179,237,0.1)" : "linear-gradient(135deg,#2b6cb0,#4299e1)", border:"none", borderRadius:"7px", padding:"6px 16px", color: analyzing ? "rgba(99,179,237,0.4)" : "#fff", fontSize:"11px", cursor: analyzing ? "not-allowed" : "pointer", fontFamily:"system-ui,sans-serif", fontWeight:"600" }}>
                {analyzing ? "Analizando..." : "Generar informe"}
              </button>
            </div>
          </div>
          <div style={{ overflowX:"auto", borderRadius:"10px", border:"1px solid rgba(255,255,255,0.07)" }}>
            <table style={{ width:"100%", borderCollapse:"collapse", fontSize:"11px", fontFamily:"monospace" }}>
              <thead><tr style={{ background:"rgba(255,255,255,0.05)" }}>{headers.map((h,i) => <th key={i} style={{ padding:"7px 10px", color:"rgba(255,255,255,0.5)", fontWeight:"400", textAlign:"left", whiteSpace:"nowrap", borderBottom:"1px solid rgba(255,255,255,0.07)" }}>{h||`Col ${i+1}`}</th>)}</tr></thead>
              <tbody>{rows.slice(0,8).map((row,i) => <tr key={i} style={{ borderBottom:"1px solid rgba(255,255,255,0.04)" }}>{row.map((cell,j) => <td key={j} style={{ padding:"6px 10px", color:"#e2e8f0", whiteSpace:"nowrap", maxWidth:"140px", overflow:"hidden", textOverflow:"ellipsis" }}>{cell instanceof Date ? cell.toLocaleDateString("es-AR") : String(cell)}</td>)}</tr>)}</tbody>
            </table>
            {rows.length > 8 && <div style={{ padding:"7px 10px", color:"rgba(255,255,255,0.25)", fontSize:"10px", fontFamily:"monospace", textAlign:"center" }}>+ {rows.length-8} filas mas...</div>}
          </div>
          {analyzing && (
            <div style={{ display:"flex", alignItems:"center", gap:"10px", padding:"14px 16px", background:"rgba(99,179,237,0.05)", border:"1px solid rgba(99,179,237,0.15)", borderRadius:"10px" }}>
              {[0,1,2].map(j => <div key={j} style={{ width:"6px", height:"6px", borderRadius:"50%", background:"#63b3ed", animation:`bounce 1.2s ${j*0.2}s infinite` }} />)}
              <span style={{ color:"rgba(255,255,255,0.4)", fontSize:"12px", fontFamily:"monospace" }}>Buscando benchmarks y analizando tu estrategia...</span>
            </div>
          )}
        </>
      )}
      {error && <div style={{ padding:"12px 16px", background:"rgba(252,129,129,0.08)", border:"1px solid rgba(252,129,129,0.2)", borderRadius:"10px", color:"#fc8181", fontSize:"12px", fontFamily:"monospace" }}>⚠️ {error}</div>}
    </div>
  );
}

// ─── CHAT PANEL ───────────────────────────────────────────────────────────────
function ChatPanel({ messages, loading, input, setInput, onSend, inputRef, messagesEndRef }) {
  const quick = ["Como esta el riesgo pais hoy?", "Analisis de GLOB hoy", "Que bono rinde mas?", "Conviene rotar algo?"];
  return (
    <>
      <div style={{ height:"360px", overflowY:"auto", padding:"16px 16px 8px", display:"flex", flexDirection:"column", gap:"11px", scrollbarWidth:"thin", scrollbarColor:"rgba(255,255,255,0.06) transparent" }}>
        {loading && messages.length === 0 && (
          <div style={{ display:"flex", gap:"8px" }}>
            <div style={{ width:"26px", height:"26px", borderRadius:"50%", background:"linear-gradient(135deg,#2b6cb0,#63b3ed)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:"11px", flexShrink:0 }}>🇦🇷</div>
            <div style={{ padding:"10px 14px", borderRadius:"14px 14px 14px 4px", background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.07)", display:"flex", gap:"5px", alignItems:"center" }}>
              {[0,1,2].map(j => <div key={j} style={{ width:"5px", height:"5px", borderRadius:"50%", background:"#63b3ed", animation:`bounce 1.2s ${j*0.2}s infinite` }} />)}
              <span style={{ color:"rgba(255,255,255,0.3)", fontSize:"10px", fontFamily:"monospace", marginLeft:"4px" }}>Analizando tu cartera...</span>
            </div>
          </div>
        )}
        {messages.map((m,i) => (
          <div key={i} style={{ display:"flex", justifyContent: m.role==="user" ? "flex-end" : "flex-start", animation:"fadeIn 0.2s ease" }}>
            {m.role==="assistant" && <div style={{ width:"26px", height:"26px", borderRadius:"50%", background:"linear-gradient(135deg,#2b6cb0,#63b3ed)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:"11px", marginRight:"7px", flexShrink:0, marginTop:"2px" }}>🇦🇷</div>}
            <div style={{ maxWidth:"85%", padding:"10px 14px", borderRadius: m.role==="user" ? "14px 14px 4px 14px" : "14px 14px 14px 4px", background: m.role==="user" ? "linear-gradient(135deg,#2b6cb0,#2c5282)" : m.auto ? "rgba(99,179,237,0.05)" : "rgba(255,255,255,0.04)", border: m.role==="user" ? "none" : m.auto ? "1px solid rgba(99,179,237,0.15)" : "1px solid rgba(255,255,255,0.07)", color:"#dde8f0", fontSize:"13px", lineHeight:"1.75", fontFamily: m.role==="user" ? "system-ui,sans-serif" : "Georgia,serif" }}>
              {m.auto && <div style={{ color:"#63b3ed", fontSize:"9px", fontFamily:"monospace", marginBottom:"5px", letterSpacing:"1.5px" }}>ANALISIS AUTOMATICO</div>}
              <div dangerouslySetInnerHTML={{ __html: fmtMsg(m.content) }} />
            </div>
          </div>
        ))}
        {loading && messages.length > 0 && (
          <div style={{ display:"flex", gap:"8px" }}>
            <div style={{ width:"26px", height:"26px", borderRadius:"50%", background:"linear-gradient(135deg,#2b6cb0,#63b3ed)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:"11px", flexShrink:0 }}>🇦🇷</div>
            <div style={{ padding:"10px 14px", borderRadius:"14px 14px 14px 4px", background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.07)", display:"flex", gap:"5px" }}>
              {[0,1,2].map(j => <div key={j} style={{ width:"5px", height:"5px", borderRadius:"50%", background:"#63b3ed", animation:`bounce 1.2s ${j*0.2}s infinite` }} />)}
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      <div style={{ padding:"0 12px 8px", display:"flex", flexWrap:"wrap", gap:"5px" }}>
        {quick.map((a,i) => (
          <button key={i} onClick={() => onSend(a)} style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:"14px", padding:"4px 10px", color:"rgba(255,255,255,0.45)", fontSize:"10px", cursor:"pointer", fontFamily:"system-ui,sans-serif", transition:"all 0.15s" }}
            onMouseOver={e => { e.target.style.background="rgba(255,255,255,0.09)"; e.target.style.color="#fff"; }}
            onMouseOut={e  => { e.target.style.background="rgba(255,255,255,0.04)"; e.target.style.color="rgba(255,255,255,0.45)"; }}
          >{a}</button>
        ))}
      </div>
      <div style={{ padding:"8px 12px 12px", borderTop:"1px solid rgba(255,255,255,0.05)", display:"flex", gap:"8px", alignItems:"flex-end" }}>
        <textarea ref={inputRef} value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key==="Enter" && !e.shiftKey) { e.preventDefault(); onSend(); } }} placeholder="Pregunta sobre cualquier activo... (Enter)" rows={1}
          style={{ flex:1, background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:"9px", padding:"9px 13px", color:"#e2e8f0", fontSize:"12px", fontFamily:"system-ui,sans-serif", resize:"none", outline:"none", lineHeight:"1.5", minHeight:"38px", maxHeight:"90px", transition:"border-color 0.15s" }}
          onFocus={e => e.target.style.borderColor = "rgba(99,179,237,0.35)"}
          onBlur={e  => e.target.style.borderColor = "rgba(255,255,255,0.08)"}
        />
        <button onClick={() => onSend()} disabled={loading || !input.trim()} style={{ width:"38px", height:"38px", borderRadius:"9px", border:"none", flexShrink:0, background: loading||!input.trim() ? "rgba(99,179,237,0.08)" : "linear-gradient(135deg,#2b6cb0,#4299e1)", color: loading||!input.trim() ? "rgba(99,179,237,0.3)" : "#fff", cursor: loading||!input.trim() ? "not-allowed" : "pointer", fontSize:"15px", display:"flex", alignItems:"center", justifyContent:"center", transition:"all 0.2s" }}>↑</button>
      </div>
    </>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [messages,    setMessages]    = useState([]);
  const [input,       setInput]       = useState("");
  const [loading,     setLoading]     = useState(false);
  const [autoLoading, setAutoLoading] = useState(true);
  const [activeTab,   setActiveTab]   = useState("chat");
  const messagesEndRef = useRef(null);
  const inputRef       = useRef(null);
  const initialized    = useRef(false);

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior:"smooth" }); }, [messages]);

  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;
    (async () => {
      try {
        const res  = await fetch("/api/chat", { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ model:"claude-sonnet-4-20250514", max_tokens:8000, system:SYSTEM_PROMPT, tools:[{ type:"web_search_20250305", name:"web_search" }], messages:[{ role:"user", content:"Haz un analisis breve (max 200 palabras) del estado actual del mercado para mi cartera: riesgo pais, CCL y precio actual de GLOB en NYSE. Termina con 1 recomendacion concreta." }] }) });
        const data = await res.json();
        setMessages([{ role:"assistant", auto:true, content: data.content?.filter(b => b.type==="text").map(b => b.text).join("") || "" }]);
      } catch { setMessages([{ role:"assistant", auto:true, content:"No pude cargar el analisis automatico. Escribime una pregunta." }]); }
      finally { setAutoLoading(false); }
    })();
  }, []);

  const sendMessage = async (custom) => {
    const msg = (custom || input).trim();
    if (!msg || loading) return;
    const next = [...messages, { role:"user", content:msg }];
    setMessages(next);
    setInput("");
    if (activeTab !== "chat") setActiveTab("chat");
    setLoading(true);
    try {
      const res  = await fetch("/api/chat", { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ model:"claude-sonnet-4-20250514", max_tokens:8000, system:SYSTEM_PROMPT, tools:[{ type:"web_search_20250305", name:"web_search" }], messages: next.map(m => ({ role:m.role, content:m.content })) }) });
      const data = await res.json();
      setMessages([...next, { role:"assistant", content: data.content?.filter(b => b.type==="text").map(b => b.text).join("") || "Sin respuesta." }]);
    } catch { setMessages([...next, { role:"assistant", content:"Error. Intenta de nuevo." }]); }
    finally { setLoading(false); }
  };

  const tabs = [{ id:"chat", label:"Asesor" }, { id:"holdings", label:"Cartera" }, { id:"excel", label:"Informe Excel" }];

  return (
    <div style={{ minHeight:"100vh", background:"#06090f", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", fontFamily:"Georgia,serif", padding:"14px" }}>
      <div style={{ position:"fixed", inset:0, pointerEvents:"none", zIndex:0, backgroundImage:"linear-gradient(rgba(99,179,237,0.025) 1px,transparent 1px),linear-gradient(90deg,rgba(99,179,237,0.025) 1px,transparent 1px)", backgroundSize:"40px 40px" }} />
      <div style={{ width:"100%", maxWidth:"820px", position:"relative", zIndex:1 }}>

        {/* Header */}
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:"12px" }}>
          <div>
            <h1 style={{ color:"#fff", fontSize:"20px", fontWeight:"300", margin:"0 0 2px", letterSpacing:"-0.3px" }}>
              Asesor <strong style={{ fontWeight:"800", background:"linear-gradient(90deg,#63b3ed,#b794f4)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>Financiero</strong>
            </h1>
            <p style={{ color:"rgba(255,255,255,0.22)", fontSize:"10px", fontFamily:"monospace", margin:0 }}>8 activos · ARS + USD · BYMA + NYSE</p>
          </div>
          <div style={{ display:"flex", alignItems:"center", gap:"5px" }}>
            <div style={{ width:"6px", height:"6px", borderRadius:"50%", background: autoLoading ? "#f6e05e" : "#68d391", boxShadow:`0 0 6px ${autoLoading ? "#f6e05e" : "#68d391"}`, animation:"pulse 2s infinite" }} />
            <span style={{ color:"rgba(255,255,255,0.22)", fontSize:"9px", fontFamily:"monospace" }}>{autoLoading ? "Cargando..." : "Live"}</span>
          </div>
        </div>

        {/* Summary cards */}
        <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:"7px", marginBottom:"12px" }}>
          {[
            { label:"Total ARS",  value: fmtARS(ARS_ACTUAL),                        sub:"7 activos",          color:"#e2e8f0" },
            { label:"Rend. ARS",  value: fmtARS(ARS_REND),                          sub: pctStr((ARS_REND/ARS_INICIAL)*100), color:"#68d391" },
            { label:"GLOB NYSE",  value:"$1,587 USD",                               sub:"-$70 USD (-4.26%)",  color:"#fc8181" },
            { label:"Meta GLOB",  value:"$60 USD",                                  sub:"faltan +$19.31",     color:"#f6e05e" },
          ].map(({ label, value, sub, color }) => (
            <div key={label} style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:"10px", padding:"9px 12px" }}>
              <div style={{ color:"rgba(255,255,255,0.3)", fontSize:"9px", textTransform:"uppercase", letterSpacing:"1.2px", fontFamily:"monospace", marginBottom:"3px" }}>{label}</div>
              <div style={{ color, fontSize:"13px", fontWeight:"700", fontFamily:"monospace" }}>{value}</div>
              <div style={{ color:"rgba(255,255,255,0.25)", fontSize:"9px", fontFamily:"monospace", marginTop:"2px" }}>{sub}</div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div style={{ display:"flex", gap:"3px", marginBottom:"10px" }}>
          {tabs.map(t => (
            <button key={t.id} onClick={() => setActiveTab(t.id)} style={{ padding:"7px 16px", borderRadius:"8px", border:"none", cursor:"pointer", background: activeTab===t.id ? "rgba(99,179,237,0.12)" : "transparent", color: activeTab===t.id ? "#63b3ed" : "rgba(255,255,255,0.3)", fontSize:"11px", fontFamily:"system-ui,sans-serif", borderBottom: activeTab===t.id ? "2px solid #63b3ed" : "2px solid transparent", transition:"all 0.2s" }}>{t.label}</button>
          ))}
        </div>

        {/* Panel */}
        <div style={{ background:"rgba(255,255,255,0.02)", border:"1px solid rgba(255,255,255,0.06)", borderRadius:"16px", overflow:"hidden", boxShadow:"0 24px 60px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.04)" }}>
          {activeTab === "chat"     && <ChatPanel messages={messages} loading={autoLoading||loading} input={input} setInput={setInput} onSend={sendMessage} inputRef={inputRef} messagesEndRef={messagesEndRef} />}
          {activeTab === "holdings" && <HoldingsTab onAsk={sendMessage} />}
          {activeTab === "excel"    && <ExcelTab />}
        </div>

        <p style={{ textAlign:"center", color:"rgba(255,255,255,0.1)", fontSize:"9px", marginTop:"10px", fontFamily:"monospace" }}>
          Solo informativo · No es asesoramiento financiero registrado
        </p>
      </div>

      <style>{`
        @keyframes pulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.4;transform:scale(.8)}}
        @keyframes bounce{0%,80%,100%{transform:translateY(0);opacity:.3}40%{transform:translateY(-5px);opacity:1}}
        @keyframes fadeIn{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:translateY(0)}}
        ::-webkit-scrollbar{width:3px}
        ::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.07);border-radius:2px}
      `}</style>
    </div>
  );
}
